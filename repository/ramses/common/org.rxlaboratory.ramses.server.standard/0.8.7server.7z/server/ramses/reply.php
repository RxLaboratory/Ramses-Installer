<?php
    //result of the request
    $reply = Array();
    $reply["accepted"] = false;
    $reply["success"] = false;
    $reply["message"] = "";
    $reply["query"] = "unknown";
    $reply["content"] = Array();
    $reply["serverUuid"] = "";
    $reply["debug"] = Array();
?>