<!DOCTYPE html>

<html lang="en-US">

<head>
<meta charset="UTF-8">
<title>Rainbox Asset Manager</title>
</head>

<body>

<form method="post" action="index.php?login">
 
<p>
    <input type="text" name="username" />
	<input type="password" name="password" />
	<input type="submit" value="Log in" />
</p>
 
</form>

</body>